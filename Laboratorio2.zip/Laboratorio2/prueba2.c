#include <avr/io.h>
#include <avr/interrupt.h>

#define LED_PASO_VEHICULOS    (1 << PB0) // LDPV

void setup() {
    // Configurar pines como entrada o salida
    DDRB = LED_PASO_VEHICULOS;

    // Configurar Timer
    TCCR1B |= (1 << WGM12); // Modo CTC
    TIMSK |= (1 << OCIE1A); // Habilitar interrupción de comparación
    OCR1A = 15624; // Para un intervalo de 1s con prescaler de 64 y reloj de 1MHz
    TCCR1B |= (1 << CS10) | (1 << CS11); // Prescaler 64
    PORTB = LED_PASO_VEHICULOS;
    sei(); // Habilitar interrupciones globales
}

// Rutina de interrupción del timer
ISR(TIMER1_COMPA_vect) {
    // Aquí podrías contar los ticks si necesitas
}

/*void FSM() {
    // Simplificado para encender sólo un LED
    PORTB = LED_PASO_VEHICULOS;
}*/

int main(void) {
    setup();
    /*while (1) {
        FSM();
        // Podrías añadir más lógica aquí más tarde
    }*/
    return 0;
}
